<header>
	<h1>SGU | Formulario de inscripci&oacute;n para nuevos usuarios</h1>
</header>
<hr>